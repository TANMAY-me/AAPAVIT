import { SolarPanelSimulation } from '@/components/SolarPanelSimulation';

const Index = () => {
  return <SolarPanelSimulation />;
};

export default Index;