import React from 'react';
import { SolarPanelScene } from '@/simulation/SolarPanelScene';
import { SimulationControls } from '@/simulation/components/SimulationControls';
import { MetricsPanel } from '@/simulation/components/MetricsPanel';
import { useSimulation } from '@/simulation/hooks/useSimulation';

export const SolarPanelSimulation: React.FC = () => {
  const {
    time,
    isPlaying,
    selectedRegion,
    selectedSeason,
    playbackSpeed,
    metrics,
    setTime,
    setPlaybackSpeed,
    handlePlayPause,
    handleReset,
    handleRegionChange,
    handleSeasonChange,
    updateMetrics,
    getCurrentTimeOfDay,
  } = useSimulation();

  return (
    <div className="simulation-container">
      {/* 3D Scene */}
      <SolarPanelScene
        time={time}
        selectedRegion={selectedRegion}
        selectedSeason={selectedSeason}
        onMetricsUpdate={updateMetrics}
      />

      {/* Control Panel */}
      <SimulationControls
        time={time}
        isPlaying={isPlaying}
        playbackSpeed={playbackSpeed}
        selectedRegion={selectedRegion}
        selectedSeason={selectedSeason}
        getCurrentTimeOfDay={getCurrentTimeOfDay}
        onTimeChange={setTime}
        onSpeedChange={setPlaybackSpeed}
        onPlayPause={handlePlayPause}
        onReset={handleReset}
        onRegionChange={handleRegionChange}
        onSeasonChange={handleSeasonChange}
      />

      {/* Metrics Panel */}
      <MetricsPanel
        metrics={metrics}
        selectedRegion={selectedRegion}
        selectedSeason={selectedSeason}
      />
    </div>
  );
};