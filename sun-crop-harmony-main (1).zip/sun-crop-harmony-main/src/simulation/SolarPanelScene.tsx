import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';

interface SolarPanelSceneProps {
  time: number;
  selectedRegion: { name: string; latitude: number };
  selectedSeason: { name: string; value: 'winter' | 'summer' | 'spring' | 'autumn' };
  onMetricsUpdate: (metrics: {
    panelTilt: number;
    sunIntensity: number;
    energyOutput: number;
    cropGrowth: number;
  }) => void;
}

export const SolarPanelScene: React.FC<SolarPanelSceneProps> = ({
  time,
  selectedRegion,
  selectedSeason,
  onMetricsUpdate
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene>();
  const rendererRef = useRef<THREE.WebGLRenderer>();
  const cameraRef = useRef<THREE.PerspectiveCamera>();
  const animationRef = useRef<number>();
  
  // Scene objects
  const sunSphereRef = useRef<THREE.Mesh>();
  const sunLightRef = useRef<THREE.DirectionalLight>();
  const panelRef = useRef<THREE.Mesh>();
  const cropsRef = useRef<Array<{ mesh: THREE.Mesh; baseHeight: number }>>([]);
  const energyLineRef = useRef<THREE.Line>();
  const energyLineMaterialRef = useRef<THREE.LineDashedMaterial>();

  // Tilt calculation based on latitude and season
  const calculateTilt = (latitude: number, season: string): number => {
    const phi = latitude;
    switch (season.toLowerCase()) {
      case 'winter': return 0.9 * phi + 29 - 4;
      case 'summer': return 0.9 * phi - 23.5 - 3;
      case 'spring':
      case 'autumn': return phi - 2.5 - 3;
      default: return phi;
    }
  };

  // Initialize Three.js scene
  useEffect(() => {
    if (!mountRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xbfeaff);
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      45,
      mountRef.current.clientWidth / mountRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.set(7, 8, 14);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;
    mountRef.current.appendChild(renderer.domElement);

    // Farm land
    const farm = new THREE.Mesh(
      new THREE.PlaneGeometry(20, 18),
      new THREE.MeshLambertMaterial({ color: 0x8b5a2b })
    );
    farm.rotateX(-Math.PI / 2);
    farm.receiveShadow = true;
    scene.add(farm);

    // Carbon fiber stand
    const stand = new THREE.Mesh(
      new THREE.CylinderGeometry(0.105, 0.13, 3.2, 32),
      new THREE.MeshPhysicalMaterial({
        color: 0x222228,
        metalness: 1,
        roughness: 0.3,
        clearcoat: 1,
      })
    );
    stand.position.set(0, 1.6, 0);
    stand.castShadow = true;
    stand.receiveShadow = true;
    scene.add(stand);

    // Transparent solar panel
    const panelGeometry = new THREE.PlaneGeometry(6, 4);
    const panelMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x00aaff,
      transparent: true,
      opacity: 0.35,
      metalness: 0.25,
      roughness: 0.2,
      clearcoat: 0.5,
    });
    const panel = new THREE.Mesh(panelGeometry, panelMaterial);
    panel.position.set(0, 3.2, 0);
    panel.castShadow = true;
    stand.add(panel);
    panelRef.current = panel;

    // Sun sphere
    const sunMaterial = new THREE.MeshLambertMaterial({
      color: 0xffee74,
      emissive: 0xffff88,
    });
    const sunSphere = new THREE.Mesh(new THREE.SphereGeometry(0.48, 32, 32), sunMaterial);
    scene.add(sunSphere);
    sunSphereRef.current = sunSphere;

    // Sun directional light
    const sunLight = new THREE.DirectionalLight(0xffffff, 1.1);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    scene.add(sunLight);
    sunLightRef.current = sunLight;

    // Ambient light
    const ambientLight = new THREE.AmbientLight(0x404040, 0.3);
    scene.add(ambientLight);

    // Crops
    const crops: Array<{ mesh: THREE.Mesh; baseHeight: number }> = [];
    const cropMaterialBaseHue = 90;
    for (let x = -2.8; x < 3; x += 1.1) {
      for (let z = -2; z < 2; z += 1.1) {
        const h = 0.85 + Math.random() * 0.45;
        const cropMaterial = new THREE.MeshLambertMaterial({
          color: new THREE.Color().setHSL((cropMaterialBaseHue + Math.random() * 40) / 360, 0.65, 0.32),
        });
        const cropGeometry = new THREE.ConeGeometry(0.17, h, 9);
        const crop = new THREE.Mesh(cropGeometry, cropMaterial);
        crop.position.set(x, h / 2 + 0.13, z);
        crop.castShadow = true;
        crop.receiveShadow = true;
        scene.add(crop);
        crops.push({ mesh: crop, baseHeight: h });
      }
    }
    cropsRef.current = crops;

    // Electricity grid
    const grid = new THREE.Mesh(
      new THREE.BoxGeometry(0.75, 1.1, 0.7),
      new THREE.MeshPhysicalMaterial({
        color: 0xddddff,
        metalness: 0.5,
        roughness: 0.3,
      })
    );
    grid.position.set(4.3, 0.57, 0);
    grid.castShadow = true;
    grid.receiveShadow = true;
    scene.add(grid);

    // Energy flow line
    const energyLineMaterial = new THREE.LineDashedMaterial({
      color: 0x00ffd2,
      dashSize: 0.21,
      gapSize: 0.1,
    });
    const linePoints = [new THREE.Vector3(2.74, 3.2, 0), new THREE.Vector3(4.3, 0.57, 0)];
    const energyLineGeometry = new THREE.BufferGeometry().setFromPoints(linePoints);
    const energyLine = new THREE.Line(energyLineGeometry, energyLineMaterial);
    energyLine.computeLineDistances();
    scene.add(energyLine);
    energyLineRef.current = energyLine;
    energyLineMaterialRef.current = energyLineMaterial;

    // Handle window resize
    const handleResize = () => {
      if (!mountRef.current || !camera || !renderer) return;
      
      const width = mountRef.current.clientWidth;
      const height = mountRef.current.clientHeight;
      
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Animation loop
  useEffect(() => {
    const animate = () => {
      if (!sceneRef.current || !rendererRef.current || !cameraRef.current) return;

      // Calculate sun position east to west
      const sunX = -5 + 10 * time;
      const sunY = 7 * Math.sin(time * Math.PI);
      
      if (sunSphereRef.current) {
        sunSphereRef.current.position.set(sunX, sunY, 0);
      }

      if (sunLightRef.current) {
        sunLightRef.current.position.set(sunX, sunY, 0);
        sunLightRef.current.target.position.set(0, 3, 0);
        sunLightRef.current.target.updateMatrixWorld();
        
        const intensity = Math.max(0.3, sunY / 7) * 1.1;
        sunLightRef.current.intensity = intensity;
      }

      // Panel tilt logic
      const maxTiltRads = (calculateTilt(selectedRegion.latitude, selectedSeason.value) * Math.PI) / 180;
      const sunElevation = Math.atan2(sunY - 3.2, sunX);
      const targetTilt = Math.min(maxTiltRads, Math.abs(sunElevation));
      
      if (panelRef.current) {
        panelRef.current.rotation.x = -targetTilt;
      }

      // Crop growth with sunlight intensity
      const sunlight = Math.max(0, sunY / 7);
      cropsRef.current.forEach((crop) => {
        crop.mesh.scale.y = 0.6 + 0.6 * sunlight * 0.35 + 0.04 * Math.sin(Date.now() / 130 + crop.baseHeight);
      });

      // Energy flow animation
      if (energyLineMaterialRef.current && energyLineRef.current) {
        if (sunlight > 0.1) {
          (energyLineMaterialRef.current as any).dashOffset -= 0.03;
          if (panelRef.current) {
            (panelRef.current.material as THREE.MeshPhysicalMaterial).emissiveIntensity = 0.19 + sunlight * 0.7;
          }
        } else {
          (energyLineMaterialRef.current as any).dashOffset = 0;
          if (panelRef.current) {
            (panelRef.current.material as THREE.MeshPhysicalMaterial).emissiveIntensity = 0.07;
          }
        }
        energyLineRef.current.geometry.computeBoundingSphere();
      }

      // Update metrics
      onMetricsUpdate({
        panelTilt: Math.round((targetTilt * 180) / Math.PI),
        sunIntensity: Math.round(sunlight * 100),
        energyOutput: Math.round(Math.max(0, sunlight * Math.cos(sunElevation - targetTilt)) * 100),
        cropGrowth: Math.round((0.6 + 0.6 * sunlight * 0.35) * 100)
      });

      rendererRef.current.render(sceneRef.current, cameraRef.current);
      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [time, selectedRegion, selectedSeason, onMetricsUpdate, calculateTilt]);

  return <div ref={mountRef} className="w-full h-full" />;
};