import React from 'react';
import { Card } from '@/components/ui/card';
import { Sun, Zap } from 'lucide-react';

interface MetricsPanelProps {
  metrics: {
    panelTilt: number;
    sunIntensity: number;
    energyOutput: number;
    cropGrowth: number;
  };
  selectedRegion: { name: string; latitude: number };
  selectedSeason: { name: string; value: string };
}

export const MetricsPanel: React.FC<MetricsPanelProps> = ({
  metrics,
  selectedRegion,
  selectedSeason,
}) => {
  return (
    <Card className="metrics-panel">
      <div className="space-y-3">
        <h3 className="font-semibold text-sm flex items-center gap-2">
          <Zap className="h-4 w-4 text-primary" />
          Live Metrics
        </h3>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Panel Tilt:</span>
            <span className="text-xs font-mono font-medium">{metrics.panelTilt}°</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Sun className="h-3 w-3" />
              Sun Intensity:
            </span>
            <span className="text-xs font-mono font-medium">{metrics.sunIntensity}%</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Energy Output:</span>
            <span className="text-xs font-mono font-medium text-success">{metrics.energyOutput}%</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Crop Growth:</span>
            <span className="text-xs font-mono font-medium text-secondary">{metrics.cropGrowth}%</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Light Penetration:</span>
            <span className="text-xs font-mono font-medium text-warning">35%</span>
          </div>
        </div>

        <div className="pt-2 border-t">
          <div className="text-xs text-muted-foreground">
            <div>Lat: {selectedRegion.latitude}°</div>
            <div>Formula: {selectedSeason.value} tilt</div>
          </div>
        </div>
      </div>
    </Card>
  );
};