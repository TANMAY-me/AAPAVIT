import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Play, Pause, RotateCcw } from 'lucide-react';
import { regions, seasons } from '../hooks/useSimulation';

interface SimulationControlsProps {
  time: number;
  isPlaying: boolean;
  playbackSpeed: number;
  selectedRegion: { name: string; latitude: number };
  selectedSeason: { name: string; value: string };
  getCurrentTimeOfDay: () => string;
  onTimeChange: (time: number) => void;
  onSpeedChange: (speed: number) => void;
  onPlayPause: () => void;
  onReset: () => void;
  onRegionChange: (regionName: string) => void;
  onSeasonChange: (seasonName: string) => void;
}

export const SimulationControls: React.FC<SimulationControlsProps> = ({
  time,
  isPlaying,
  playbackSpeed,
  selectedRegion,
  selectedSeason,
  getCurrentTimeOfDay,
  onTimeChange,
  onSpeedChange,
  onPlayPause,
  onReset,
  onRegionChange,
  onSeasonChange,
}) => {
  return (
    <Card className="control-panel">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <h3 className="font-semibold text-sm">Simulation Controls</h3>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onPlayPause}
            className="h-8 w-8 p-0"
          >
            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={onReset}
            className="h-8 w-8 p-0"
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-medium">Time: {getCurrentTimeOfDay()}</label>
          <Slider
            value={[time]}
            onValueChange={([value]) => onTimeChange(value)}
            max={1}
            min={0}
            step={0.01}
            className="w-32"
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-medium">Speed: {playbackSpeed}x</label>
          <Slider
            value={[playbackSpeed]}
            onValueChange={([value]) => onSpeedChange(value)}
            max={5}
            min={0.1}
            step={0.1}
            className="w-32"
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-medium">Region</label>
          <Select
            value={selectedRegion.name}
            onValueChange={onRegionChange}
          >
            <SelectTrigger className="w-40 h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {regions.map(region => (
                <SelectItem key={region.name} value={region.name}>
                  {region.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-medium">Season</label>
          <Select
            value={selectedSeason.name}
            onValueChange={onSeasonChange}
          >
            <SelectTrigger className="w-40 h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {seasons.map(season => (
                <SelectItem key={season.name} value={season.name}>
                  {season.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </Card>
  );
};