import { useState, useEffect, useCallback } from 'react';

interface Region {
  name: string;
  latitude: number;
}

interface Season {
  name: string;
  value: 'winter' | 'summer' | 'spring' | 'autumn';
}

interface SimulationMetrics {
  panelTilt: number;
  sunIntensity: number;
  energyOutput: number;
  cropGrowth: number;
}

export const regions: Region[] = [
  { name: 'South India (Chennai)', latitude: 13 },
  { name: 'Central India (Nagpur)', latitude: 21 },
  { name: 'North India (Delhi)', latitude: 28 },
];

export const seasons: Season[] = [
  { name: 'Winter', value: 'winter' },
  { name: 'Summer', value: 'summer' },
  { name: 'Spring', value: 'spring' },
  { name: 'Autumn', value: 'autumn' },
];

export const useSimulation = () => {
  // Simulation state
  const [time, setTime] = useState(0.25); // Start at sunrise (6 AM)
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedRegion, setSelectedRegion] = useState<Region>(regions[1]); // Central India default
  const [selectedSeason, setSelectedSeason] = useState<Season>(seasons[1]); // Summer default
  const [playbackSpeed, setPlaybackSpeed] = useState(1);

  // Simulation metrics
  const [metrics, setMetrics] = useState<SimulationMetrics>({
    panelTilt: 0,
    sunIntensity: 0,
    energyOutput: 0,
    cropGrowth: 0,
  });

  // Auto-play animation
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isPlaying) {
      interval = setInterval(() => {
        setTime(prev => {
          const newTime = prev + (0.005 * playbackSpeed);
          return newTime > 1 ? 0 : newTime;
        });
      }, 50);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlaying, playbackSpeed]);

  const handlePlayPause = useCallback(() => {
    setIsPlaying(!isPlaying);
  }, [isPlaying]);

  const handleReset = useCallback(() => {
    setTime(0.25);
    setIsPlaying(false);
  }, []);

  const getCurrentTimeOfDay = useCallback(() => {
    const hours = Math.floor(time * 24);
    const minutes = Math.floor((time * 24 - hours) * 60);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  }, [time]);

  const handleRegionChange = useCallback((regionName: string) => {
    const region = regions.find(r => r.name === regionName);
    if (region) setSelectedRegion(region);
  }, []);

  const handleSeasonChange = useCallback((seasonName: string) => {
    const season = seasons.find(s => s.name === seasonName);
    if (season) setSelectedSeason(season);
  }, []);

  const updateMetrics = useCallback((newMetrics: SimulationMetrics) => {
    setMetrics(newMetrics);
  }, []);

  return {
    // State
    time,
    isPlaying,
    selectedRegion,
    selectedSeason,
    playbackSpeed,
    metrics,
    
    // Actions
    setTime,
    setPlaybackSpeed,
    handlePlayPause,
    handleReset,
    handleRegionChange,
    handleSeasonChange,
    updateMetrics,
    
    // Computed
    getCurrentTimeOfDay,
  };
};